﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestAkron.Models;

namespace TestAkron.Controllers
{

    [Authorize(Roles = "Admin")]
    public class ControlController : Controller
    {
        ApplicationDbContext db;

        public ControlController()
        {
            db = new ApplicationDbContext();
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id) /*Удаляю из бд выбранного пользоватля*/
        {
            var user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string id) /*нахожу пользователя и возвращаю во Вью*/
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        [HttpPost]
        public JsonResult SaveMpass(int id, string val) /*Сохраняю изменный пароль*/
        {
            try
            {
                MasterPass mp = new MasterPass { ID = id, MasterKey = val };
                db.Entry(mp).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return Json("ОК");
            }
            catch (Exception) { return Json("ERROR"); }
        }

        
        public ActionResult Index() /*Формирую список пользователей с ролями и вывожу во вьюмодель*/
        {
            var usersWithRoles = (from user in db.Users
                                  select new
                                  {
                                      UserId = user.Id,
                                      Username = user.UserName,
                                      Email = user.Email,
                                      RoleNames = (from userRole in user.Roles
                                                   join role in db.Roles on userRole.RoleId
                                                   equals role.Id
                                                   select role.Name).ToList()
                                  }).ToList().Select(p => new Users_in_Role_ViewModel()
                                  {
                                      UserId = p.UserId,
                                      Username = p.Username,
                                      Email = p.Email,
                                      Role = string.Join(",", p.RoleNames)
                                  });

            UserMasPassViewModel um = new UserMasPassViewModel
            {
                MP = db.MasterPasses.ToList(),
                ANU = usersWithRoles.Where(x => !x.Role.Contains("Admin"))
            };

            return View(um);

        }
    }
}