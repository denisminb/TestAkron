﻿using PagedList;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TestAkron.Models;

namespace TestAkron.Controllers
{
    public class HomeController : Controller
    {
        ApplicationDbContext db;
        public HomeController()
        {
            db = new ApplicationDbContext();
        }



        public ViewResult Index(string sortOrder, string currentFilter, string searchString, int? page)        
        {
            ViewBag.CurrentSort = sortOrder; // сортировка
            ViewBag.Email = sortOrder == "Email" ? "email_desc" : "Email";            
            ViewBag.FromAdress = sortOrder == "FromAdress" ? "from_desc" : "FromAdress";
            ViewBag.WhereAdress = sortOrder == "WhereAdress" ? "where_desc" : "WhereAdress";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var list = from a in db.Zakazs.Where(x=>x.Stat!= "Отказано пользователем").ToList() select a; // вывожу список
            if (!String.IsNullOrEmpty(searchString)) // если не пустая строка с фильтром
            {
                list = list.Where(s => s.Email.ToLower().Contains(searchString.ToLower())
                || s.FromAdress.ToLower().Contains(searchString.ToLower()) || s.WhereAdress.ToLower().Contains(searchString.ToLower())
                ); // формируем список согласно фильтру
            }

            switch (sortOrder)
            {
                case "email_desc":
                    list = list.OrderByDescending(s => s.Email);
                    break;
                case "FromAdress":
                    list = list.OrderBy(s => s.FromAdress);
                    break;
                case "WhereAdress":
                    list = list.OrderByDescending(s => s.WhereAdress);
                    break;
                default:
                    list = list.OrderByDescending(s => s.ID);
                    break;
            }
            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(list.ToPagedList(pageNumber, pageSize));            
        }


        
        public ActionResult AddZakaz()
        {
            return View();
        }

        [HttpPost]       
        public async Task<ActionResult> AddZakaz(
            [Bind(Include = "ID,Email,Dat,FromAdress,WhereAdress,Comment")] Zakaz zakaz
            )  /*Согласно модели данных сохраняю заказ*/
        {
            try
            {
                if (ModelState.IsValid)
                {
                    zakaz.Stat = "Новый";
                    db.Zakazs.Add(zakaz);
                    await db.SaveChangesAsync();
                }
            }
            catch (RetryLimitExceededException )
            {
                ModelState.AddModelError("", "Попробуйте заново сохранить, иначе свяжитесь с ....");
            }
            return View(zakaz);
        }

        public ActionResult OtkazUser(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var zak = db.Zakazs.Find(id);
            if (zak == null)
            {
                return HttpNotFound();
            }
            return View(zak); /*Вывожу нужный заказ для отмены по ИД*/

        }

        [HttpPost, ActionName("OtkazUser")]
        [ValidateAntiForgeryToken]
        public ActionResult OtkazConfirmed(int id)
        {
            var s = db.Zakazs.Find(id);
            s.Stat = "Отказано пользователем";
            db.SaveChanges();
            return RedirectToAction("Index"); /*Сохраняю отказ*/
        }
    }
}