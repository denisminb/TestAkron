﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Owin;
using System;
using TestAkron.Models;

[assembly: OwinStartupAttribute(typeof(TestAkron.Startup))]
namespace TestAkron
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            createRolesandUsers();
        }


        private void createRolesandUsers()
        {
            try
            {
                ApplicationDbContext db = new ApplicationDbContext();
                var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(db));
                var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));

                if (!roleManager.RoleExists("Admin")) /*Если нет роли Админа создаем роль и пользователя Админа */
                {
                    var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                    role.Name = "Admin";
                    roleManager.Create(role);
                    var user = new ApplicationUser();
                    user.UserName = "Admin";
                    string userPWD = "!23Qwe";
                    var chkUser = UserManager.Create(user, userPWD);
                    if (chkUser.Succeeded)
                    {
                        var result1 = UserManager.AddToRole(user.Id, "Admin");
                    }

                    try
                    {
                        MasterPass mp = new MasterPass { MasterKey = "TestKey" };
                        db.MasterPasses.Add(mp);
                        db.SaveChanges();
                    }
                    catch (Exception q)
                    { }
                }

                if (!roleManager.RoleExists("Dispatcher"))
                {
                    var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                    role.Name = "Dispatcher";
                    roleManager.Create(role);
                }

                if (!roleManager.RoleExists("Driver"))
                {
                    var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                    role.Name = "Driver";
                    roleManager.Create(role);
                }
            }
            catch (Exception) { }

        }
    }
}
