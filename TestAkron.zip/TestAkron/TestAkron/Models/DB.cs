﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TestAkron.Models
{
    /*модель заказов*/
    public class Zakaz
    {
        public int ID { get; set; }
        [Required]
        public string Email { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd'/'MM'/'yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Дата поездки")]
        public DateTime Dat { get; set; }
        [Required]
        public string FromAdress { get; set; }
        [Required]
        public string WhereAdress { get; set; }
        [Required]
        public string Comment { get; set; }
        public string Stat { get; set; }
        public virtual ICollection<DriverZak> DriverZaks { get; set; }
    }

    /*модель создана для Диспетчеров/Водителей связанная с заказами  */
    public class DriverZak
    {        
        public int ID { get; set; }
        [Key]
        [MaxLength(128)]
        public string UserID { get; set; }        
        public int ZakazID { get; set; }
        public virtual Zakaz Zakaz { get; set; }
        
    }
   
    /*Модель для хранения мастер-пароля*/
    [Table("MasterPass")]
    public class MasterPass
    {
        public int ID { get; set; }
        public string MasterKey { get; set; }
    }


    /*Модель пользователей для отображения в элементе Управление*/
    public class Users_in_Role_ViewModel
    {
        public string UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
    }


    /*Модель создана для объединения двух моделей и отображение их в элементе Управление*/
    public class UserMasPassViewModel
    {
        public IEnumerable<MasterPass> MP { get; set; }

        public IEnumerable<Users_in_Role_ViewModel> ANU { get; set; }
    }

}